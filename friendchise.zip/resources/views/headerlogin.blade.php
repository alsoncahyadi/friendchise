<!-- Buat parent template yang nantinya akan diturunkan ke view yang lain misal homepage sama about-->

<!DOCTYPE html>
<html>

</html>
