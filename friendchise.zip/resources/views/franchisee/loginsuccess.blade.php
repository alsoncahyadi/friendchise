@extends('template')

@section('main')
    <div id='franchisee'>
        <h2> Login SUCCESSFUL </h2>
    </div>
@stop

@section('footer')
    @include('footer')
@stop